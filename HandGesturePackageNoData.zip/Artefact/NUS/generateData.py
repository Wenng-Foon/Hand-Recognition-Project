import shutil, random, os

random.seed(10)

backgroundPath = './NUS Hand Posture dataset-II/Backgrounds'
handPath = './NUS Hand Posture dataset-II/Hand Postures'
hand2Path = './NUS Hand Posture dataset-II/Hand Postures with human noise'


handDirectory = './RecognitionData'
balancedDirectory = './End2EndBalanced'
end2endDirectory = './End2EndData'
detectorDirectory ='../Detector/NUS/DetectorData'


print("Creating RecognitionData...")
filenames = os.listdir(handPath)
for fname in filenames:
    srcpath = os.path.join(handPath, fname)
    shutil.copy(srcpath, handDirectory)
    
filenames = os.listdir(hand2Path)
for fname in filenames:
    srcpath = os.path.join(hand2Path, fname)
    shutil.copy(srcpath, handDirectory)
    
if os.path.exists(os.path.join(handDirectory, 'Thumbs.db')):
    os.remove(os.path.join(handDirectory, 'Thumbs.db'))

print("Creating End2EndData...")
filenames = os.listdir(backgroundPath)
for fname in filenames:
    srcpath = os.path.join(backgroundPath, fname)
    shutil.copy(srcpath, end2endDirectory)
    
filenames = os.listdir(handDirectory)
for fname in filenames:
    srcpath = os.path.join(handDirectory, fname)
    shutil.copy(srcpath, end2endDirectory)

if os.path.exists(os.path.join(end2endDirectory, 'Thumbs.db')):
    os.remove(os.path.join(end2endDirectory, 'Thumbs.db'))
    
print("Creating End2EndBal...")
filenames = random.sample(os.listdir(backgroundPath), 275)
for fname in filenames:
    srcpath = os.path.join(backgroundPath, fname)
    shutil.copy(srcpath, balancedDirectory)
    
filenames = os.listdir(handDirectory)
for fname in filenames:
    srcpath = os.path.join(handDirectory, fname)
    shutil.copy(srcpath, balancedDirectory)

if os.path.exists(os.path.join(balancedDirectory, 'Thumbs.db')):
    os.remove(os.path.join(balancedDirectory, 'Thumbs.db'))
    
if os.path.exists(detectorDirectory):
    shutil.rmtree(detectorDirectory)
    
print("Creating DetectorData...")
shutil.copytree(end2endDirectory, detectorDirectory)
    

