import argparse
import os
import time
import cv2
import numpy as np
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.transforms as transforms
import torch.optim as optim
from model import Attention_ResNet50, Attention_CAMNet
from PIL import Image

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("-id", "--exp_id", type=str, default='res0')
    parser.add_argument("-e2e", "--end2end", type=int, default=0)
    parser.add_argument("-m", "--mode", choices=["normal", "se", "cbam", "cam" ], default="normal", help="To train a normal resnet or with SE/CBAM, or Class Activation Map")
    parser.add_argument("-v", "--visual", choices=["normal", "heatmap", "binary" ], default="normal", help="Heatmap only works for cam mode")

    args = parser.parse_args()
    return args

if __name__ == '__main__':
    args = parse_args()

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")


if args.end2end == 1:
    class_dict = {0:"background", 1:'a', 2:'b', 3:'c', 4:'d', 5:'e', 6:'f', 7:'g', 8:'h', 9:'i', 10:'j'}
    features = 11
else:
    class_dict = {0:'a', 1:'b', 2:'c', 3:'d', 4:'e', 5:'f', 6:'g', 7:'h', 8:'i', 9:'j'}
    features = 10
    
if args.visual != "normal":
    visual = True
else:
    visual = False

if args.mode == "cbam":
    model = Attention_ResNet50(num_features = features, use_Spatial= True, visual = visual).to(device)
elif args.mode == "se":
    model = Attention_ResNet50(num_features = features, use_Spatial= False, visual = visual).to(device)
elif args.mode == "cam":
    model = Attention_CAMNet(num_features = features, use_Spatial= True).to(device)
else:
    model = models.resnet50(pretrained=pretrained)
    model.fc = nn.Linear(2048, features)
    model = model.to(device)


checkpoint_path = './{}_{}_checkpoint.pth'.format(args.exp_id, args.mode)
assert os.path.exists(checkpoint_path), ('checkpoint do not exits for %s' % checkpoint_path)
checkpoint = torch.load(checkpoint_path)

model.load_state_dict(checkpoint['model_state_dict'])
model = model.to(device)

    
transform = transforms.Compose([
    transforms.Resize((180, 160)),
    transforms.ToTensor(),
    #transforms.Normalize(mean=[0.5, 0.5, 0.5],
    #                     std=[0.5, 0.5, 0.5])
    transforms.Normalize(mean=[0.485, 0.456, 0.406],
                         std=[0.229, 0.224, 0.225])
])
"""
transform = transforms.Compose([
    transforms.Resize((180, 160)),
    transforms.RandomHorizontalFlip(),
    transforms.RandomRotation(20),
    transforms.RandomAffine(20, translate=(0.2, 0.2)),
    transforms.ToTensor(),
    #transforms.Normalize(mean=[0.485, 0.456, 0.406],
    #                     std=[0.229, 0.224, 0.225])
])
"""

font                   = cv2.FONT_HERSHEY_SIMPLEX
top                    = (20,20)
bottomLeft             = (50,50)
fontScale              = .5
fontColor              = (255,255,255)
lineType               = 2


prev_frame_time = time.time()
with torch.no_grad():

    cap = cv2.VideoCapture(0,cv2.CAP_DSHOW)
    
    while cap.isOpened():

        ret, frame = cap.read()
        
        frame = frame[120:360, 160:480]
        #frame = cv2.imread('./NUS/RecognitionData/a (34).jpg')
        
        #img = frame
        img = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        imgPIL = Image.fromarray(img)
        
        img = transform(imgPIL)
        img = img.to(device)
        img = img.unsqueeze(0)
        
        # Make detections 
        if args.mode == "cam" and visual:
            cls_scores, _, feature_maps, weights, _, _, _ = model(img)
            cls_scores = cls_scores.squeeze()
            #print(cls_scores)
            
            # feature maps are 1 x 256 x 45 x 40
            
            weights = F.softmax(weights, dim = 1)
            heatmap = (feature_maps*weights).squeeze()
            heatmap = heatmap.sum(0).cpu().numpy()

            
            heatmap = heatmap - np.min(heatmap)
            heatmap = heatmap / np.max(heatmap)
            heatmap = np.uint8(255 * heatmap)
            heatmap = cv2.resize(heatmap, (320,240))
            
            if args.visual == 'binary':
                _, binary = cv2.threshold(heatmap, 180, 255, cv2.THRESH_BINARY)
                frame = binary
            else: 
                heatmap = cv2.applyColorMap(heatmap, cv2.COLORMAP_JET)
                frame = heatmap
        
        else:
            if visual:
                cls_scores, heatmap = model(img)
                heatmap = heatmap.squeeze()
                heatmap = heatmap.sum(0).cpu().numpy()
                heatmap = heatmap - np.min(heatmap)
                heatmap = heatmap / np.max(heatmap)
                heatmap = np.uint8(255 * heatmap)
                heatmap = cv2.resize(heatmap, (320,240))
                
                if args.visual == 'binary':
                    _, binary = cv2.threshold(heatmap, 180, 255, cv2.THRESH_BINARY)
                    #frame = binary
                else: 
                    heatmap = cv2.applyColorMap(heatmap, cv2.COLORMAP_JET)
                    #frame = heatmap
            else:
                cls_scores = model(img)[0].squeeze()
                
            cls_scores = cls_scores.squeeze()

        predict = torch.argmax(cls_scores).item()
        score = cls_scores[predict]
        class_name = class_dict[predict]
        
        # FPS calc
        new_frame_time = time.time()
        fps = round(1/(new_frame_time-prev_frame_time))
        prev_frame_time = new_frame_time
        
        img = img.cpu()
        img = img[0].numpy().transpose(1, 2, 0)
        
        cv2.putText(frame, "Class {} with score: {}".format(class_name, score), top, font, fontScale, fontColor, lineType)
        cv2.putText(frame, "FPS: {}".format(fps), bottomLeft, font, fontScale, fontColor, lineType)

        cv2.imshow('Hand Detection', frame)

        if args.visual == 'heatmap':
            cv2.imshow('Heatmap', heatmap)
        if args.visual == 'binary':
            cv2.imshow('Binary', binary)
    
        if cv2.waitKey(10) & 0xFF == ord('q'):
            break
    cap.release()
    cv2.destroyAllWindows()
