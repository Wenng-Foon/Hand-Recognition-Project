No models were provided due to the file size. However some models are available via the google drive link:
https://drive.google.com/drive/folders/1-YXMNLZc289emeIaFaFr09-YXYUJMf3h
The training logs all all models trained are in the result folders. 
Please contact us via email if you are interested in the model.

main_train.py - the main file used to run train models
model.py - the file where we created the models
model_resnet10.py - the file where we created the resnet10 model
detection_dataloader.py - the dataclass files
train_detector.py - the files containing the training, evaluate and resume functions.

YOLOv5.ipynb - the jupyter file used to train the yolov5 model with the egoGesture Dataset
webcam_test.ipynb - the jupyter file used to test the yolov5 model


**To train a detector model (examples):**

python main_train.py -id res10 -e 100 -b 16 -lr 1e-3 -m "cbam"
python main_train.py -id res10 -e 100 -b 16 -lr 1e-3 -m "normal"
python main_train.py -id res10 -e 100 -b 16 -lr 1e-3 -m "se"

Flag Details:
-id   the id of the model
-m    the mode of the model, choices are ["normal", "se", "cbam"]
	To train a normal resnet or with SE/CBAM
-red  the reduction_ratio for the SE module, default=16
-pool pooling type used by the SE module, choices=["avg", "max", "both" ], default="avg"

-b    the batch_size, default=16
-e    the number of training epochs, default=50
-lr   the learning_rate, default=1e-3

--seed  random seed for repeatability
--resume resume the trained model of the same id and settings
--test  test with trained model of the same id and settings


**To use the real-time webcam application (Example):**

python webcam_detection.py 

(manually change line 19 for other models)