Initial Setup: 
To setup the dataset, download the NUS hand posture data set II from https://www.ece.nus.edu.sg/stfpage/elepv/NUS-HandSet/

Extract all files into the NUS file, then run the python script inside the NUS directory:
python generateData.py


All relevant code for the detector is in the detector file
No models were provided due to the file size. However some models are available via the google drive link:
https://drive.google.com/drive/folders/1-YXMNLZc289emeIaFaFr09-YXYUJMf3h
The training logs all all models trained are in the result folders. 
Please contact us via email if you are interested in the model.

main.py - the main file used to run train models
model.py - the file where we created the models
recognition_dataloader.py - the dataclass files
train.py - the files containing the training, evaluate and resume functions.
VideoDemo.mkv - a video demo of the CBAM recogniser network.

There is also a Jupyter notebook file used to plot the visualisations of the accuracy  and loss data in the results folder

*Note Detector has its own ReadMe file*


**To train a recogniser/end-to-end model (examples):**

python main.py -id recogniser -e 150 -b 16 -lr 1e-3 -pre 1 -m "cbam"
python main.py -id end2end -e2e 2 -e 150 -b 16 -lr 1e-3 -pre 1 -m "cbam"
python main.py -id end2endCam -e2e 2 -e 150 -b 16 -lr 1e-3 -pre 1 -m "cam"

Flag Details:
-id   the id of the model
-e2e  signifies if a model will be end to end or not, default=0
	(0: normal recogniser, 1: end2end training with imbalance data, 2: end2end with balanced data)
-m    the mode of the model, choices are ["normal", "se", "cbam", "cam" ]
	To train a normal resnet or with SE/CBAM, or Class Activation Map
-b    the batch_size, default=16
-e    the number of training epochs, default=50
-lr   the learning_rate, default=1e-3
-wd   the weight_decay(L2 regularisation) default=0
-pre  initialise model pretrain, default=1
-red  the reduction_ratio for the SE module, default=16
-pool pooling type used by the SE module, choices=["avg", "max", "both" ], default="avg"

--seed  random seed for repeatability
--resume resume the trained model of the same id and settings
--test  test with trained model of the same id and settings


**To use the real-time webcam application (Example):**

python webcam_recognition.py -id recogniser -m cbam -v heatmap
python webcam_recognition.py -id end2end -m cbam -v heatmap
python webcam_recognition.py -id end2endCam -m cam -v heatmap


-id   the id of the model
-e2e  specifies if the model is end to end or not, default=0
-m    the mode the model was trained on, default="normal"
	 choices=["normal", "se", "cbam", "cam" ]
-v    specify the visualisation type, choices=["normal", "heatmap", "binary"], default="normal"
