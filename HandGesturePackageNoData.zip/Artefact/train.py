import os
import time
import torch
import torch.nn as nn
import torch.nn.functional as F

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

criterion = torch.nn.CrossEntropyLoss()

def train(args, model, optimizer, dataloaders):
    trainloader, testloader = dataloaders

    best_testing_accuracy = 0.0

    # training
    for epoch in range(args.epochs):
        model.train()

        batch_time = time.time(); iter_time = time.time()
        for i, data in enumerate(trainloader):

            imgs, labels = data
            imgs, labels = imgs.to(device), labels.to(device)

            cls_scores = model(imgs)
            loss = criterion(cls_scores, labels)

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            if i % 50 == 0 and i != 0:
                print('epoch:{}, iter:{}, time:{:.2f}, loss:{:.5f}'.format(epoch, i,
                    time.time()-iter_time, loss.item()))
                iter_time = time.time()
        batch_time = time.time() - batch_time
        print('[epoch {} | time:{:.2f} | loss:{:.5f}]'.format(epoch, batch_time, loss.item()))
        print('-------------------------------------------------')

        if epoch % 1 == 0:
            testing_accuracy = evaluate(args, model, testloader)
            print('testing accuracy: {:.3f}'.format(testing_accuracy))

            if testing_accuracy > best_testing_accuracy:
                ### compare the previous best testing accuracy and the new testing accuracy
                ### save the model and the optimizer --------------------------------
                #
                torch.save({'epoch': epoch,
                            'accuracy' : testing_accuracy,
                            'loss' : loss.item(),
                            'model_state_dict': model.state_dict(),
                            'optimizer_state_dict': optimizer.state_dict()
                            }, './{}_{}_checkpoint.pth'.format(args.exp_id, args.mode))
                            
                best_testing_accuracy = testing_accuracy
                #
                #
                ### -----------------------------------------------------------------
                print('new best model saved at epoch: {}'.format(epoch))
    print('-------------------------------------------------')
    print('best testing accuracy achieved: {:.3f}'.format(best_testing_accuracy))

    

def train_CAM(args, model, optimizer, dataloaders, alpha = 0.8):
    trainloader, testloader = dataloaders

    best_testing_accuracy = 0.0

    # training
    for epoch in range(args.epochs):
        model.train()

        batch_time = time.time(); iter_time = time.time()
        for i, data in enumerate(trainloader):

            imgs, labels = data
            imgs, labels = imgs.to(device), labels.to(device)

            scores_F, scores_L, feature_maps_L, w_L, scores_S, feature_maps_S, w_S= model(imgs)
            loss_L = criterion(scores_L, labels)
            loss_S = criterion(scores_S, labels)
            loss_F = criterion(scores_F, labels)
            
            _,_,h,w = feature_maps_S.shape
            
            feature_maps_L = F.interpolate(feature_maps_L, size=(h,w), mode='bilinear')
            w_L = F.softmax(w_L, dim=1)
            w_S = F.softmax(w_S, dim=1)
            
            segL = torch.sum(w_L * feature_maps_L, dim=1)
            segS = torch.sum(w_S * feature_maps_S, dim=1)

            loss_seg = nn.MSELoss()(segL,segS)
            loss =  (1-alpha) * ((loss_L + loss_S)/2  + loss_seg) +  alpha*loss_F

            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            if i % 50 == 0 and i != 0:
                print('epoch:{}, iter:{}, time:{:.2f}, loss:{:.5f}'.format(epoch, i,
                    time.time()-iter_time, loss.item()))
                iter_time = time.time()
        batch_time = time.time() - batch_time
        print('[epoch {} | time:{:.2f} | loss:{:.5f}]'.format(epoch, batch_time, loss.item()))
        print('-------------------------------------------------')

        if epoch % 1 == 0:
            testing_accuracy = evaluate(args, model, testloader)
            print('testing accuracy: {:.3f}'.format(testing_accuracy))

            if testing_accuracy > best_testing_accuracy:
                ### compare the previous best testing accuracy and the new testing accuracy
                ### save the model and the optimizer --------------------------------
                #
                torch.save({'epoch': epoch,
                            'accuracy' : testing_accuracy,
                            'loss' : loss.item(),
                            'model_state_dict': model.state_dict(),
                            'optimizer_state_dict': optimizer.state_dict()
                            }, './{}_{}_checkpoint.pth'.format(args.exp_id, args.mode))
                            
                best_testing_accuracy = testing_accuracy
                #
                #
                ### -----------------------------------------------------------------
                print('new best model saved at epoch: {}'.format(epoch))
    print('-------------------------------------------------')
    print('best testing accuracy achieved: {:.3f}'.format(best_testing_accuracy))
    
    
    
def evaluate(args, model, testloader):
    total_count = torch.tensor([0.0],device=device); correct_count = torch.tensor([0.0],device=device)
    for i, data in enumerate(testloader):
        imgs, labels = data
        imgs, labels = imgs.to(device), labels.to(device)

        total_count += labels.size(0)

        with torch.no_grad():
            if args.mode == "cam":
                cls_scores = model(imgs)[0]
            else:
                cls_scores = model(imgs)

            predict = torch.argmax(cls_scores, dim=1)
            correct_count += (predict == labels).sum()
    testing_accuracy = correct_count / total_count
    return testing_accuracy.item()


def resume(args, model, optimizer):
    checkpoint_path = './{}_{}_checkpoint.pth'.format(args.exp_id, args.mode)
    assert os.path.exists(checkpoint_path), ('checkpoint do not exits for %s' % checkpoint_path)

    ### load the model and the optimizer --------------------------------

    checkpoint = torch.load(checkpoint_path)
    model.load_state_dict(checkpoint['model_state_dict'])
    optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
    epoch = checkpoint['epoch']
    testing_accuracy = checkpoint['accuracy']
    loss = checkpoint['loss']

    print("resuming from epoch {}, testing_accuracy: {}, loss: {} ".format(epoch, testing_accuracy, loss))
    
    model.to(device)
    ### -----------------------------------------------------------------

    print('Resume completed for the model\n')

    return model, optimizer
