a08 represents the alpha of 0.8 in the SSE CAM variant of the end to end network (only for CAM Mode)
wd representes weight decay of 1e-4 (0 otherwise)
bal represents training on the balanced dataset (275 images of 11 class including background), else its the 4750 images dataset
cbam represents Training with the CBAM attention module